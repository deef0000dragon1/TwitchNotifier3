package tech.deef.twitch.server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Twitch/*")
public class TwitchServer extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Set response content type
		response.setContentType("text/html");

		// Actual logic goes here.

		PrintWriter out = response.getWriter();

		/*
		 * String username = request.getPathInfo().substring(1); DataPull pull =
		 * new DataPuller(); TwitchAPI puller = new TwitchAPIPull(pull);
		 * GetStreams pulling = new GetStreams(puller); String[] liveNames =
		 * null; liveNames =
		 * pulling.getLiveStreams(GetFollowed.getFollowed(puller.
		 * getUserFollowsChannels(username)));
		 * 
		 * for (String name : liveNames) { out.println("<h1>" + "input user: " +
		 * name + "</h1>"); }
		 */
		out.println("<h1>" + "input user: " + "</h1>");

	}

	public void destroy() {
		// do nothing.
	}
}
