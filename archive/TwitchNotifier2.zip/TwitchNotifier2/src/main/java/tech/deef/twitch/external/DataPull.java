package tech.deef.twitch.external;

public interface DataPull {

	public String PullData(String location);
}
